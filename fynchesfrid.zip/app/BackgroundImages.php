<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BackgroundImages extends Model
{
    protected $fillable = ['image_url'];
}
