<?php

namespace App\Http\Controllers\Site;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\UserMeta;
use App\GiftPurchase;

class CheckoutController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
    	
    }

   /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(){
        
        $session_id = session()->getId();
        
        $gift_purchase = GiftPurchase::where('session_id', $session_id)->get();
        
        $session_total = $gift_purchase->sum('amount');
        
        $count = count($gift_purchase);
   
        return view('site.checkout.checkout', compact('gift_purchase', 'session_total', 'count'));
        
        
      }
      
      public function checkoutsuccess(){
          if (Auth::check()) {
            
            $user = Auth::user();
   
            	return view('site.checkout.checkout-success', compact('user'));
            
        } else {
            
        return redirect()->route('home');
        
        }
      }
      
      public function remove(Request $request){
          
            $purchase_id = $request->gift_id;
            
            $destroy = GiftPurchase::destroy($purchase_id);
            
            return response()->json(['result' => $purchase_id]);
       
      }
      
      public function order(Request $request){
          
            $purchase_id = $request->gift_id;
            
            
            return response()->json(['result' => $purchase_id]);
       
      }
      
      
	    
}