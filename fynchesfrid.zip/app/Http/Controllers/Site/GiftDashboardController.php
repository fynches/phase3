<?php

namespace App\Http\Controllers\Site;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\User;
use App\Gift;
use App\GiftPage;
use App\Offer;
use App\Company;
use App\Templates;
use DB;
use Session;
use Route;
use App\ActivityLog;
use Auth;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Input;

use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\URL;
use Laravel\Socialite\Facades\Socialite;
use Yajra\Datatables\Datatables;
use App\Site;
use App\Event;
use App\Experience;
use App\FundingReport;
use App\Testimonial;
use App\StaticBlock;

class GiftDashboardController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
    	
    }

   /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (Auth::check()) {
            
        $user = Auth::user();
        
	    $giftPages = GiftPage::where('user_id',$user->id)->get();
	    
    	return view('site.gift-dashboard.index', compact('giftPages'));
        }
	} 
	
	public function gifted()
	{
	    if (Auth::check()) {
            
        $user = Auth::user();
        
	    $gift_page =  GiftPage::where('user_id', $user->id)->first();
	    
	    if(isset($gift_page->added_gifts)) {
            $added_gifts_ids = unserialize($gift_page->added_gifts);
            $gifts = Gift::whereIn('id',$added_gifts_ids)->get();
        }
	    
    	return view('site.gift-dashboard.gifted', compact('gifts'));
        }
	}   
    
}
