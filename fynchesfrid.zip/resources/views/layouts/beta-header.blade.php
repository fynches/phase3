<header>
	<!-- Menu Toggle -->	
	<nav class="navbar navbar-expand-lg navbar-default beta-pg">
		<div class="container">
			<a class="navbar-brand" href="#">
	         <img src="{{asset('front/img/logo.png')}}" alt="Fynches" title="">
	        </a>
	        <!-- <button class="navbar-toggler navbar-toggler-right collapsed" type="button" data-toggle="collapse" data-target="#collapsingNavbar">
	            <span> </span>
	            <span> </span>
	            <span> </span>
	        </button> -->
	        <!-- <div class="navbar-collapse" id="collapsingNavbar">
	            <ul class="nav navbar-nav ml-auto social">
					<li><a href="javascript:void(0)"><i class="fab fa-twitter"></i></a></li>
					<li><a href="javascript:void(0)"><i class="fab fa-facebook-f"></i></a></li>
					<li><a href="javascript:void(0)"><i class="fab fa-instagram"></i></a></li>
					<li><a href="javascript:void(0)"><i class="fab fa-pinterest-p"></i></a></li>
				</ul>
	        </div> -->
	        <ul class="nav navbar-nav ml-auto social">
				<li><a href="javascript:void(0)"><i class="fab fa-twitter"></i></a></li>
				<li><a href="javascript:void(0)"><i class="fab fa-facebook-f"></i></a></li>
				<li><a href="javascript:void(0)"><i class="fab fa-instagram"></i></a></li>
				<li><a href="javascript:void(0)"><i class="fab fa-pinterest-p"></i></a></li>
			</ul>
	    </div>
	</nav>
	<!-- End -->
</header>