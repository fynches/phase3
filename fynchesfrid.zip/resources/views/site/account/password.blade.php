<form id="accPass" onsubmit="event.preventDefault();">
    <div class="form-row">
    <div class="form-group col-md-6">
      <label for="cpass">Current Password</label>
      <input type="password" class="form-control" id="cpass" required>
    </div>
  </div>
  <div class="form-row">
  <div class="form-group col-md-6">
    <label for="npass">New Password</label>
    <input type="password" class="form-control" id="npass" required>
  </div>
  </div>
  <div id="pass-row" class="form-row">
  <div class="form-group col-md-6">
    <label for="cnpass">Confirm New Password</label>
    <input type="password" class="form-control" id="cnpass" required>
  </div>
  </div>
  <div class="form-row">
            <div class="col-md-6" style="padding:0px">
                <input id="accPass-submit" type="submit" class="purple-submit pointer" value="SAVE CHANGES">
            </div>
        </div>  
</form>
