<form id="congrats" method="GET" action="">
    <div class="container">
        <div class="row form-section">
            <div class="col-md-12">
                <h2 class="text-center">CONGRATULATIONS, YOU'RE READY TO GO!</h2>
            </div>
        </div>
        <div class="row">
            
            <div class="col-md-12 text-center">
                <img src="public/front/img/Congrats.png" alt="bird" title="" class="img-fluid" width="450px">
            </div>
        </div>
        <div class="row">
            <div class="col-md-12 text-center">
                <input id="page-link" type="submit" class="yellow-submit" value="GO TO GIFT PAGE">
            </div>
        </div>
        
    </div>
</form>