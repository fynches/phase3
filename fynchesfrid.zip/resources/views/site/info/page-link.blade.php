<form id="pageLink" onsubmit="event.preventDefault();">
    <div class="container">
        <div class="row form-section">
            <div class="col-md-12">
                <h2 class="text-center" style="font-weight:bold">LET'S GIVE YOUR GIFT PAGE A PERSONAL TOUCH</h2>
            </div>
        </div>
        <div class="row">
            
            <div class="col-md-12 text-center">
                <h5 style="margin-bottom:20px;font-family: 'Futura-Medium';font-weight: bold;font-size: 16px;">What Would You Like The Link to Your Gift Page To Be?</h5>
                <div class="guest">This link is how your guests will find your gift page. Make it simple and easy to remember.</div>
                
            </div>
            <div class="col-md-12 text-center">
                <div class="row" id="lk">
                    <div class="col-md-4 col-xs-6 text-right">
                <p id="gp">https://www.fynches.com/gift-page/</p>
                </div>
                <div class="col-md-6 col-xs-6 text-left" >
                <input required id="your-link" type="text" placeholder="" style="width: 100%;border-radius: 0 5px 5px 0;" value="" pattern="[A-Za-z0-9]*">
                <p>Please use only letters or numbers only</p>
                </div>
            </div>  
        </div>
        </div>
        <div class="row">
            <div class="col-md-12 text-center">
                
                <input id="page-link" type="submit" class="yellow-submit pointer" value="NEXT STEP">
            </div>
        </div>
        
    </div>
</form>