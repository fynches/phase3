<div class="modal" id="gift_share" tabindex="-1" role="dialog">
  <div class="modal-dialog  modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-body">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="$('#gift_share').hide();">
          <span aria-hidden="true">&times;</span>
        </button>
         
         <div class="container text-center">
                <img src="http://fynches.codeandsilver.com/public/front/img/logo_3.png">
          </div>
          
          <p class="text-center">SHARE YOUR PAGE WITH A FRIEND</p>
          <div class="cont_1">
              
              <div class="row">
                  <div class="col-md-12">
                      <label>Email Address</label>
                      <input type="text" class="form-control">
                  </div>
                  
                  <div class="col-md-12">
                      <label>Subject</label>
                      <input type="text" class="form-control" placeholder="Subject Populates the gift title">
                  </div>
                  
                  <div class="col-md-12">
                      <label>Message</label><br>
                       <textarea type="text" name="message">Message populates the link to the page</textarea>
                  </div>
                  
                  <button class="btn btn-lg yellow_submit">SEND MESSAGE</button>
                  
              </div>
              
          </div>
         
         
         
      <div class="modal-footer" style="border-top: 0px solid #e5e5e5;">
      </div>
    </div>
  </div>
</div>
</div>
