<?php $__env->startSection('header'); ?>
    <header>
        <div class="container">
            <div class="row">
                <div class="fheader col-md-8">
                    <h1 id="hd">FYNCHES</h1>
                </div>
                <div class="col-md-4">
                    <div class="fmenu" id="div_top_hypers">
                         <ul id="ul_top_hypers">
                            <li><a href="" class="a_top_hypers"> HELP</a></li>
                                <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">MY ACCOUNT <span class="caret"></span></a>
                                <ul class="dropdown-menu" role="menu">
                                    <li><a href="/account">ACCOUNT SETTINGS</a></li>
                                    <li><a href="/gift-dashboard">DASHBOARD</a></li>
                                    <li><a href="<?php echo e(url('/logout')); ?>">LOGOUT</a></li>
                                </ul>
                                </li>
                           </div>
                         </ul>
</div>
                </div>
            </div>
        </div>    
    </header>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row" style="margin-top:50px;">
        <div class="col-md-3">
            <ul class="dashboard-list">
                <h4>Dashboard</h4>
                <li><a href="/gift-dashboard">Gift Pages</a></li>
                <li><a href="/gifted">Gifted</a></li>
            </ul>
        </div>
        <div class="col-md-8">
            <div class="row">
                <h3>Gifted</h3>
                <a href="/parent-child-info" style="color:#fff;margin-left:auto" class="pointer"><button class="create-gift" style="margin-left:auto;">Create Gift Page</button></a>
            </div>
            <div class="row" style="margin-top:50px;">
                <h3 style="height:50px; overflow: hidden;">GIFTED   --------------------------------------------------------------------------------------------------------------</h3>
            </div>
            <?php if(isset($gifts)): ?>
                <?php $__currentLoopData = $gifts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gift): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row" style="margin-top:50px;">
                    <div class="media">
                        <span class="media-left">
                            <img src="http://fynches.codeandsilver.com/public/front/img/img5.png" alt="Image Here">
                        </span>
                        <div class="media-body" style="margin-left:20px;">
                            <h4><?php echo e($gift['title']); ?></h4>
                            <p><?php echo e($gift['details']); ?></p>
                        </div>
                    </div>
                </div>
                <div class="row" style="margin-top:50px;">
                    <p class="gifted_right">Gifted To: <?php echo e($gift['name']); ?></p> <p>Gifted $<?php echo e($gift['price']); ?> of $<?php echo e($gift['price']); ?> Requested</p>
                    <p class="gifted_too_left">Gifted On: <?php echo e(date_create_from_format('Y-m-d', $gift['date_gifted'])->format('m-d-Y')); ?></p>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
 


<?php echo $__env->make('site.gift-dashboard.gift-info', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>