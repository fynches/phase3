<header>
	<!-- Menu Toggle -->	
	<nav class="navbar navbar-expand-lg navbar-default beta-pg">
		<div class="container">
			<a class="navbar-brand" href="<?php echo e(URL::to('/')); ?>">
	         <img src="<?php echo e(asset('public/front/img/logo.png')); ?>" alt="Fynches" title="">
	        </a>	       
	        <!-- <ul class="nav navbar-nav ml-auto social">
				<li><a href="https://twitter.com/fynches" target="_blank"><i class="fab fa-twitter"></i></a></li>
				<li><a href="https://www.facebook.com/fynchescom" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
				<li><a href="https://www.instagram.com/fynches" target="_blank"><i class="fab fa-instagram"></i></a></li>
				<li><a href="javascript:void(0)" target="_blank"><i class="fab fa-pinterest-p"></i></a></li>
			</ul> -->
			<button class="" style="background-color: #faf8f2;cursor: pointer;" data-toggle="modal" data-target="#largeModalSI">LOG IN</button>
			<button class="btn common pink-btn" style="cursor: pointer;background-color: #faf8f2;width: auto;border: 1px solid #f05;border-radius: 25px;color: #f05;font-weight: bold;" data-toggle="modal" data-target="#largeModalS">SIGN UP FREE</button>
            
	    </div>
	</nav>
	<!-- End -->
</header>