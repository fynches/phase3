<!-- <section class="two-box-sec">
	<div class="container">
		<div class="row">
			<?php if(isset($testimonails)): ?>
				<?php $__currentLoopData = $testimonails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php
				
		        $defaultPath = 'storage/no-img.jpg';
		        $TestimonaialImage = $val->image;
		
		        if ($TestimonaialImage && $TestimonaialImage != "") {
		            
		            $imgPath = 'storage/testimonialImages/' . $TestimonaialImage;
		           
		            if (file_exists($imgPath))
		            {
		                $imgPath = $imgPath;
		            } else {
		                $imgPath = $defaultPath;
		            }
		        } else {
		            $imgPath = $defaultPath;
		        }?>
				<div class="col-sm-12 col-md-5">
				<div class="color-box">
					<img class="color-box" src="<?php echo e(asset($imgPath)); ?>" alt="" title="">
				</div>
				<blockquote class="blockquote text-center">
					<h3>"<?php echo e($val->name); ?>"</h3>
				    <?php echo html_entity_decode($val->description); ?>

				    <footer class="blockquote-footer"><?php echo e($val->author_name); ?>.</footer>
				 </blockquote>
			</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php endif; ?>
		</div>
	</div>
</section> -->
<!-- Kids and Parents Sec -->
<section class="slider-sec">
  <h2 class="title">Kids and Parents Love Fynches</h2>
  <div class="owl-carousel">
    <div class="item">
      <div class="lft-sec">
      	<div class="rounded-circle">
      		<img src="<?php echo e(asset('public/front/img/Mom.png')); ?>" alt="" title="" class="img-fluid">
      	</div>
      </div>
      <div class="rgt-sec">
      	<blockquote>
		    <p>Fynches is my go-to birthday solution for my daughter. Love it! </p>
		    <footer>- Heather M.</footer>
		</blockquote>
      </div>
    </div>
    <div class="item">
      <div class="lft-sec">
      	<div class="rounded-circle">
      		<img src="<?php echo e(asset('public/front/img/Couple.png')); ?>" alt="" title="" class="img-fluid">
      	</div>
      </div>
      <div class="rgt-sec">
      	<blockquote>
		    <p>Fynches is my go-to birthday solution for my daughter. Love it! </p>
		    <footer>- Heather M.</footer>
		</blockquote>
      </div>
    </div>
    <div class="item">
      <div class="lft-sec">
      	<div class="rounded-circle">
      		<img src="<?php echo e(asset('public/front/img/Mom.png')); ?>" alt="" title="" class="img-fluid">
      	</div>
      </div>
      <div class="rgt-sec">
      	<blockquote>
		    <p>Fynches is my go-to birthday solution for my daughter. Love it! </p>
		    <footer>- Heather M.</footer>
		</blockquote>
      </div>
    </div>
    <div class="item">
      <div class="lft-sec">
      	<div class="rounded-circle">
      		<img src="<?php echo e(asset('public/front/img/Couple.png')); ?>" alt="" title="" class="img-fluid">
      	</div>
      </div>
      <div class="rgt-sec">
      	<blockquote>
		    <p>Fynches is my go-to birthday solution for my daughter. Love it! </p>
		    <footer>- Heather M.</footer>
		</blockquote>
      </div>
    </div>
  </div>
</section>
<!-- End -->